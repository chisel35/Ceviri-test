package com.kemal.ceviritelefon;

public class Status {
    public static volatile String model = "Model: henüz indirilmedi";
    public static volatile String cap = "Yakalama: durdu";
    public static volatile String net = "TV: henüz gönderilmedi";
    public static volatile String ocr = "";
    public static volatile String tr = "";
}
