package com.kemal.ceviritelefon;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class SelectView extends View {

    public interface Listener {
        void onSelected(float l, float t, float r, float b);

        void onCancel();
    }

    private final Paint fill = new Paint();
    private final Paint border = new Paint();
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float x0, y0, x1, y1;
    private boolean has = false;
    private Listener listener;

    public SelectView(Context c) {
        super(c);
        fill.setColor(Color.argb(60, 0, 255, 120));
        border.setColor(Color.rgb(0, 255, 120));
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(6f);
        text.setColor(Color.WHITE);
        text.setTextSize(42f);
        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.argb(120, 0, 0, 0));
        canvas.drawText("Altyazının çıktığı alanı parmağınla çiz (bırakınca kaydedilir)",
                getWidth() / 2f, getHeight() * 0.12f, text);
        canvas.drawText("Sadece dokunup bırakırsan iptal olur",
                getWidth() / 2f, getHeight() * 0.12f + 56f, text);
        if (has) {
            float l = Math.min(x0, x1);
            float r = Math.max(x0, x1);
            float t = Math.min(y0, y1);
            float b = Math.max(y0, y1);
            canvas.drawRect(l, t, r, b, fill);
            canvas.drawRect(l, t, r, b, border);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x0 = e.getX();
                y0 = e.getY();
                x1 = x0;
                y1 = y0;
                has = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                x1 = e.getX();
                y1 = e.getY();
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                x1 = e.getX();
                y1 = e.getY();
                float w = getWidth();
                float h = getHeight();
                float l = Math.max(0f, Math.min(x0, x1)) / w;
                float r = Math.min(w, Math.max(x0, x1)) / w;
                float t = Math.max(0f, Math.min(y0, y1)) / h;
                float b = Math.min(h, Math.max(y0, y1)) / h;
                if (listener != null) {
                    if ((r - l) < 0.05f || (b - t) < 0.03f) {
                        listener.onCancel();
                    } else {
                        listener.onSelected(l, t, r, b);
                    }
                }
                return true;
            default:
                return true;
        }
    }
}
