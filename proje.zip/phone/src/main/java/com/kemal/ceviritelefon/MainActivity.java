package com.kemal.ceviritelefon;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText ipBox;
    private EditText glossBox;
    private TextView st;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("p", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 30, 40, 30);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#101418"));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Çeviri Telefon (v2)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        root.addView(title);

        ipBox = addField(root, "TV IP adresi (örn. 192.168.1.20)", prefs.getString("ip", ""));

        TextView gl = new TextView(this);
        gl.setText("Sözlük (her satıra bir kayıt). Çevrilmeyecek isim: Kratos   |   Sabit çeviri: Vault=Sığınak");
        gl.setTextColor(Color.parseColor("#C8D1DC"));
        gl.setTextSize(14);
        gl.setPadding(0, 16, 0, 0);
        root.addView(gl);

        glossBox = new EditText(this);
        glossBox.setText(prefs.getString("glossary", ""));
        glossBox.setTextColor(Color.WHITE);
        glossBox.setHint("Kratos\nMaster Chief\nVault=Sığınak");
        glossBox.setHintTextColor(Color.GRAY);
        glossBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        glossBox.setMinLines(4);
        glossBox.setGravity(Gravity.TOP);
        root.addView(glossBox);

        Button bo = addButton(root, "0) 'Üstte gösterme' iznini ver (alan seçmek için, bir kez)");
        Button b1 = addButton(root, "1) Çeviri modelini indir (bir kez, internet gerekir)");
        Button b4 = addButton(root, "2) TV'ye test mesajı gönder");
        Button b2 = addButton(root, "3) BAŞLAT (ekran okuma)");
        Button b5 = addButton(root, "4) ALAN SEÇ (5 sn sonra açılır, Xbox görüntüsüne geç)");
        Button b3 = addButton(root, "5) DURDUR");

        st = new TextView(this);
        st.setTextColor(Color.parseColor("#C8D1DC"));
        st.setTextSize(16);
        st.setPadding(0, 20, 0, 0);
        root.addView(st);

        bo.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                Status.cap = "İzin ekranı açılamadı: " + e.getClass().getSimpleName();
            }
        });

        b1.setOnClickListener(v -> Engine.downloadModel());

        b4.setOnClickListener(v -> {
            save();
            Engine.send(ipBox.getText().toString().trim(), "Telefon bağlantısı çalışıyor");
        });

        b2.setOnClickListener(v -> {
            save();
            try {
                MediaProjectionManager m =
                        (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), 1);
            } catch (Exception e) {
                Status.cap = "Ekran yakalama açılamadı: " + e;
            }
        });

        b5.setOnClickListener(v -> {
            if (CaptureService.instance == null) {
                Status.cap = "Önce 3) BAŞLAT'a bas";
                return;
            }
            if (!Settings.canDrawOverlays(this)) {
                Status.cap = "Önce 0) düğmesiyle 'Üstte gösterme' iznini ver";
                return;
            }
            Status.cap = "5 sn içinde Xbox görüntüsüne geç, seçim ekranı açılacak";
            ui.postDelayed(() -> {
                CaptureService s = CaptureService.instance;
                if (s != null) {
                    s.startSelect();
                }
            }, 5000);
        });

        b3.setOnClickListener(v -> stopService(new Intent(this, CaptureService.class)));

        ui.post(new Runnable() {
            @Override
            public void run() {
                st.setText(Status.model + "\n" + Status.cap + "\n" + Status.net
                        + "\n\nOkunan: " + Status.ocr + "\n\nÇeviri: " + Status.tr);
                ui.postDelayed(this, 500);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode != RESULT_OK || data == null) {
                Status.cap = "Ekran yakalama izni verilmedi";
                return;
            }
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("code", resultCode);
            i.putExtra("data", data);
            i.putExtra("ip", ipBox.getText().toString().trim());
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(i);
                } else {
                    startService(i);
                }
            } catch (Exception e) {
                Status.cap = "Servis başlatılamadı: " + e;
            }
        }
    }

    private void save() {
        prefs.edit()
                .putString("ip", ipBox.getText().toString().trim())
                .putString("glossary", glossBox.getText().toString())
                .apply();
    }

    private EditText addField(LinearLayout parent, String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        parent.addView(e);
        return e;
    }

    private Button addButton(LinearLayout parent, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        parent.addView(b);
        return b;
    }
}
