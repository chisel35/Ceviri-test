package com.kemal.ceviritelefon;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText ipBox;
    private EditText topBox;
    private EditText botBox;
    private TextView st;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("p", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 30, 40, 30);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#101418"));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Çeviri Telefon (v1)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        root.addView(title);

        ipBox = addField(root, "TV IP adresi (örn. 192.168.1.20)", prefs.getString("ip", ""), false);
        topBox = addField(root, "Okunacak alan: üst % (örn. 70)", prefs.getString("top", "70"), true);
        botBox = addField(root, "Okunacak alan: alt % (örn. 95)", prefs.getString("bot", "95"), true);

        Button b1 = addButton(root, "1) Çeviri modelini indir (bir kez, internet gerekir)");
        Button b4 = addButton(root, "2) TV'ye test mesajı gönder");
        Button b2 = addButton(root, "3) BAŞLAT (ekran okuma)");
        Button b3 = addButton(root, "4) DURDUR");

        st = new TextView(this);
        st.setTextColor(Color.parseColor("#C8D1DC"));
        st.setTextSize(16);
        st.setPadding(0, 20, 0, 0);
        root.addView(st);

        b1.setOnClickListener(v -> Engine.downloadModel());

        b4.setOnClickListener(v -> {
            save();
            Engine.send(ipBox.getText().toString().trim(), "Telefon bağlantısı çalışıyor");
        });

        b2.setOnClickListener(v -> {
            save();
            try {
                MediaProjectionManager m =
                        (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), 1);
            } catch (Exception e) {
                Status.cap = "Ekran yakalama açılamadı: " + e;
            }
        });

        b3.setOnClickListener(v -> stopService(new Intent(this, CaptureService.class)));

        ui.post(new Runnable() {
            @Override
            public void run() {
                st.setText(Status.model + "\n" + Status.cap + "\n" + Status.net
                        + "\n\nOkunan: " + Status.ocr + "\n\nÇeviri: " + Status.tr);
                ui.postDelayed(this, 500);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode != RESULT_OK || data == null) {
                Status.cap = "Ekran yakalama izni verilmedi";
                return;
            }
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("code", resultCode);
            i.putExtra("data", data);
            i.putExtra("ip", ipBox.getText().toString().trim());
            i.putExtra("top", parse(topBox.getText().toString(), 70));
            i.putExtra("bottom", parse(botBox.getText().toString(), 95));
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(i);
                } else {
                    startService(i);
                }
            } catch (Exception e) {
                Status.cap = "Servis başlatılamadı: " + e;
            }
        }
    }

    private int parse(String s, int def) {
        try {
            int v = Integer.parseInt(s.trim());
            return Math.max(0, Math.min(100, v));
        } catch (Exception e) {
            return def;
        }
    }

    private void save() {
        prefs.edit()
                .putString("ip", ipBox.getText().toString().trim())
                .putString("top", topBox.getText().toString().trim())
                .putString("bot", botBox.getText().toString().trim())
                .apply();
    }

    private EditText addField(LinearLayout parent, String hint, String value, boolean number) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setSingleLine(true);
        e.setInputType(number ? InputType.TYPE_CLASS_NUMBER
                : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        parent.addView(e);
        return e;
    }

    private Button addButton(LinearLayout parent, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        parent.addView(b);
        return b;
    }
}
