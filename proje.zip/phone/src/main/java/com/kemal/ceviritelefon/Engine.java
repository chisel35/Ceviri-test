package com.kemal.ceviritelefon;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Engine {

    public static final Translator translator = Translation.getClient(
            new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.TURKISH)
                    .build());

    public static volatile boolean modelReady = false;

    private static final ExecutorService net = Executors.newSingleThreadExecutor();

    public static void downloadModel() {
        Status.model = "Model indiriliyor (internet gerekir, bir kez)...";
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> {
                    modelReady = true;
                    Status.model = "Model hazır (İngilizce → Türkçe)";
                })
                .addOnFailureListener(e -> {
                    Status.model = "Model hatası: " + e.getMessage();
                });
    }

    public static void send(final String ip, final String text) {
        call(ip, "/s?t=" + enc(text));
    }

    public static void clear(final String ip) {
        call(ip, "/clear");
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static void call(final String ip, final String path) {
        net.execute(() -> {
            try {
                URL u = new URL("http://" + ip + ":8765" + path);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                int code = c.getResponseCode();
                c.disconnect();
                Status.net = "TV: gönderildi (" + code + ")";
            } catch (Exception e) {
                Status.net = "TV: gönderilemedi (" + e.getClass().getSimpleName() + ")";
            }
        });
    }
}
