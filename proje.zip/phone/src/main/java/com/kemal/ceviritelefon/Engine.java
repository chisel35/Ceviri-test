package com.kemal.ceviritelefon;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Engine {

    public interface Callback {
        void done(String result, String error);
    }

    public static final Translator translator = Translation.getClient(
            new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.TURKISH)
                    .build());

    public static volatile boolean modelReady = false;

    private static final ExecutorService net = Executors.newSingleThreadExecutor();

    // Aynı cümleyi tekrar çevirmemek için önbellek (ana iş parçacığından kullanılır)
    private static final LinkedHashMap<String, String> cache =
            new LinkedHashMap<String, String>(64, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, String> e) {
                    return size() > 100;
                }
            };

    // Çevirmeden korunacak isimler için, makine çevirisinin olduğu gibi bıraktığı uydurma isimler
    private static final String[] PH = {
            "Zorion", "Velkan", "Bramwell", "Orsino", "Tiberon", "Kaldrith", "Mervyn", "Dacian"
    };

    private static final Pattern CAPS = Pattern.compile(
            "(?<=[a-z0-9,;]\\s)([A-Z][a-z'’\\-]+(?:\\s[A-Z][a-z'’\\-]+)*)");

    private static final Set<String> EXCL = new HashSet<>(Arrays.asList(
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
            "January", "February", "March", "April", "May", "June", "July", "August",
            "September", "October", "November", "December", "English", "Turkish", "God",
            "Christmas"));

    static class Protected {
        String text;
        final ArrayList<String[]> pairs = new ArrayList<>();

        String restore(String tr) {
            String r = tr;
            for (String[] pr : pairs) {
                if (!r.contains(pr[0])) {
                    return null;
                }
                r = r.replace(pr[0], pr[1]);
            }
            return r;
        }
    }

    public static void clearCache() {
        cache.clear();
    }

    public static void downloadModel() {
        Status.model = "Model indiriliyor (internet gerekir, bir kez)...";
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> {
                    modelReady = true;
                    Status.model = "Model hazır (İngilizce → Türkçe)";
                })
                .addOnFailureListener(e -> {
                    Status.model = "Model hatası: " + e.getMessage();
                });
    }

    // ---------- Sözlük ----------
    // Satır biçimi:  Kratos   veya   Vault=Sığınak   (# ile başlayan satır yorumdur)
    public static List<String[]> parseGlossary(String s) {
        List<String[]> list = new ArrayList<>();
        if (s == null) {
            return list;
        }
        for (String line : s.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            String src = line;
            String tgt = line;
            int eq = line.indexOf('=');
            if (eq > 0) {
                src = line.substring(0, eq).trim();
                tgt = line.substring(eq + 1).trim();
            }
            if (!src.isEmpty()) {
                list.add(new String[]{src, tgt.isEmpty() ? src : tgt});
            }
        }
        Collections.sort(list, (a, b) -> b[0].length() - a[0].length());
        return list;
    }

    private static Protected protect(String text, boolean heuristic, List<String[]> glossary) {
        Protected p = new Protected();
        String s = text;
        int idx = 0;
        for (String[] g : glossary) {
            if (idx >= PH.length) {
                break;
            }
            Matcher m = Pattern.compile("\\b" + Pattern.quote(g[0]) + "\\b",
                    Pattern.CASE_INSENSITIVE).matcher(s);
            if (m.find()) {
                s = m.replaceAll(Matcher.quoteReplacement(PH[idx]));
                p.pairs.add(new String[]{PH[idx], g[1]});
                idx++;
            }
        }
        if (heuristic) {
            Map<String, String> seen = new HashMap<>();
            Matcher m = CAPS.matcher(s);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String w = m.group(1);
                String rep = w;
                if (!(w.startsWith("I'") || w.startsWith("I’") || EXCL.contains(w))) {
                    String ph = seen.get(w);
                    if (ph == null && idx < PH.length) {
                        ph = PH[idx++];
                        seen.put(w, ph);
                        p.pairs.add(new String[]{ph, w});
                    }
                    if (ph != null) {
                        rep = ph;
                    }
                }
                m.appendReplacement(sb, Matcher.quoteReplacement(rep));
            }
            m.appendTail(sb);
            s = sb.toString();
        }
        p.text = s;
        return p;
    }

    // ---------- Çeviri ----------
    public static void translate(final String body, boolean heuristic, List<String[]> glossary,
                                 final Callback cb) {
        final String ckey = body.toLowerCase(Locale.ENGLISH);
        String hit = cache.get(ckey);
        if (hit != null) {
            cb.done(hit, null);
            return;
        }
        final Protected p = protect(body, heuristic, glossary);
        final String src = p.text.length() > 300 ? p.text.substring(0, 300) : p.text;
        translator.translate(src)
                .addOnSuccessListener(tr -> {
                    String res = p.restore(tr);
                    if (res == null) {
                        // Çeviri korunan ismi kaybetti: korumasız çevirip onu kullan
                        String plain = body.length() > 300 ? body.substring(0, 300) : body;
                        translator.translate(plain)
                                .addOnSuccessListener(t2 -> {
                                    cache.put(ckey, t2);
                                    cb.done(t2, null);
                                })
                                .addOnFailureListener(e -> cb.done(null, e.getMessage()));
                    } else {
                        cache.put(ckey, res);
                        cb.done(res, null);
                    }
                })
                .addOnFailureListener(e -> cb.done(null, e.getMessage()));
    }

    // ---------- Metin yardımcıları ----------
    public static String normKey(String s) {
        return s.toLowerCase(Locale.ENGLISH).replaceAll("[^a-z0-9]", "");
    }

    public static double similarity(String a, String b) {
        if (a.equals(b)) {
            return 1.0;
        }
        int n = a.length();
        int m = b.length();
        if (n == 0 || m == 0) {
            return 0.0;
        }
        int[] prev = new int[m + 1];
        int[] cur = new int[m + 1];
        for (int j = 0; j <= m; j++) {
            prev[j] = j;
        }
        for (int i = 1; i <= n; i++) {
            cur[0] = i;
            for (int j = 1; j <= m; j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return 1.0 - (double) prev[m] / Math.max(n, m);
    }

    public static boolean mostlyUpper(String s) {
        int letters = 0;
        int up = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetter(c)) {
                letters++;
                if (Character.isUpperCase(c)) {
                    up++;
                }
            }
        }
        return letters >= 8 && up * 10 >= letters * 7;
    }

    public static String sentenceCase(String s) {
        String l = s.toLowerCase(Locale.ENGLISH);
        StringBuilder sb = new StringBuilder();
        boolean cap = true;
        for (int i = 0; i < l.length(); i++) {
            char c = l.charAt(i);
            if (cap && Character.isLetter(c)) {
                sb.append(Character.toUpperCase(c));
                cap = false;
            } else {
                sb.append(c);
            }
            if (c == '.' || c == '!' || c == '?') {
                cap = true;
            }
        }
        return sb.toString().replaceAll("\\bi\\b", "I");
    }

    public static boolean looksLikeText(String t) {
        int letters = 0;
        int nonSpace = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (!Character.isWhitespace(c)) {
                nonSpace++;
                if (Character.isLetter(c)) {
                    letters++;
                }
            }
        }
        return letters >= 4 && letters * 10 >= nonSpace * 6;
    }

    // ---------- TV'ye gönderme ----------
    public static void send(final String ip, final String text) {
        call(ip, "/s?t=" + enc(text));
    }

    public static void clear(final String ip) {
        call(ip, "/clear");
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static void call(final String ip, final String path) {
        net.execute(() -> {
            try {
                URL u = new URL("http://" + ip + ":8765" + path);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                int code = c.getResponseCode();
                c.disconnect();
                Status.net = "TV: gönderildi (" + code + ")";
            } catch (Exception e) {
                Status.net = "TV: gönderilemedi (" + e.getClass().getSimpleName() + ")";
            }
        });
    }
}
