package com.kemal.ceviritelefon;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CaptureService extends Service {

    public static volatile CaptureService instance;

    private static final int STABLE = 2;
    private static final Pattern SPEAKER = Pattern.compile(
            "(?:^|(?<=\\s))([A-Z][A-Za-z0-9'’.\\-]{1,19}(?: [A-Z][A-Za-z0-9'’.\\-]{1,19}){0,2}):\\s+");
    private static final Set<String> NOT_SPEAKER = new HashSet<>(Arrays.asList(
            "note", "warning", "tip", "hint", "objective", "mission", "quest", "chapter",
            "controls", "loading"));

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler bg;
    private TextRecognizer recognizer;
    private volatile boolean running = false;
    private volatile boolean selecting = false;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private SelectView selView;

    private String ip = "";
    private List<String[]> glossary = new ArrayList<>();
    private volatile float rl = 0.05f;
    private volatile float rt = 0.70f;
    private volatile float rr = 0.95f;
    private volatile float rb = 0.97f;

    private String lastShownKey = null;
    private String candKey = null;
    private String candText = "";
    private int candCount = 0;
    private int emptyCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "SELECT".equals(intent.getAction())) {
            if (running) {
                startSelect();
            } else {
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running || intent == null) {
            return START_NOT_STICKY;
        }

        SharedPreferences prefs = getSharedPreferences("p", MODE_PRIVATE);
        ip = intent.getStringExtra("ip");
        glossary = Engine.parseGlossary(prefs.getString("glossary", ""));
        rl = prefs.getFloat("rl", 0.05f);
        rt = prefs.getFloat("rt", 0.70f);
        rr = prefs.getFloat("rr", 0.95f);
        rb = prefs.getFloat("rb", 0.97f);
        Engine.clearCache();

        startAsForeground();
        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);

            ht = new HandlerThread("cap");
            ht.start();
            bg = new Handler(ht.getLooper());

            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                }
            }, bg);

            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE))
                    .getDefaultDisplay().getRealMetrics(dm);
            int scale = Math.max(dm.widthPixels, dm.heightPixels) > 2560 ? 2 : 1;
            int w = dm.widthPixels / scale;
            int h = dm.heightPixels / scale;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("cap", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, bg);

            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            if (!Engine.modelReady) {
                Engine.downloadModel();
            }
            running = true;
            Status.cap = "Yakalama: çalışıyor (" + w + "x" + h + ")";
            bg.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!running) {
                        return;
                    }
                    tick();
                    bg.postDelayed(this, 450);
                }
            }, 1000);
        } catch (Exception e) {
            Status.cap = "Yakalama başlatılamadı: " + e;
        }
        return START_NOT_STICKY;
    }

    // ---------- Alan seçme ----------
    public void startSelect() {
        if (!running || selView != null) {
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Status.cap = "Alan seçmek için uygulamadaki 'Üstte gösterme izni' gerekli";
            return;
        }
        final SelectView v = new SelectView(this);
        v.setListener(new SelectView.Listener() {
            @Override
            public void onSelected(float l, float t, float r, float b) {
                rl = l;
                rt = t;
                rr = r;
                rb = b;
                getSharedPreferences("p", MODE_PRIVATE).edit()
                        .putFloat("rl", l).putFloat("rt", t)
                        .putFloat("rr", r).putFloat("rb", b).apply();
                lastShownKey = null;
                candKey = null;
                candCount = 0;
                closeSelect();
                Toast.makeText(CaptureService.this, "Alan kaydedildi", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancel() {
                closeSelect();
            }
        });
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try {
            ((WindowManager) getSystemService(WINDOW_SERVICE)).addView(v, lp);
            selView = v;
            selecting = true;
        } catch (Exception e) {
            Status.cap = "Seçim ekranı açılamadı: " + e;
        }
    }

    private void closeSelect() {
        selecting = false;
        if (selView != null) {
            try {
                ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(selView);
            } catch (Exception ignored) {
            }
            selView = null;
        }
    }

    // ---------- Ekran okuma ----------
    private void tick() {
        if (selecting || busy.get()) {
            return;
        }
        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) {
                return;
            }
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int ps = p.getPixelStride();
            int rs = p.getRowStride();
            int w = img.getWidth();
            int h = img.getHeight();

            Bitmap full = Bitmap.createBitmap(rs / ps, h, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            int x0 = (int) (w * rl);
            int x1 = (int) (w * rr);
            int y0 = (int) (h * rt);
            int y1 = (int) (h * rb);
            if (x1 - x0 < 40 || y1 - y0 < 20) {
                x0 = 0;
                x1 = w;
                y0 = h * 70 / 100;
                y1 = h * 95 / 100;
            }
            Bitmap crop = Bitmap.createBitmap(full, x0, y0, x1 - x0, y1 - y0);
            full.recycle();

            busy.set(true);
            recognizer.process(InputImage.fromBitmap(crop, 0))
                    .addOnSuccessListener(res -> handleText(res.getText()))
                    .addOnFailureListener(e -> {
                        Status.ocr = "OCR hatası: " + e.getMessage();
                        busy.set(false);
                    });
        } catch (Exception e) {
            Status.cap = "Yakalama hatası: " + e;
            busy.set(false);
        } finally {
            if (img != null) {
                img.close();
            }
        }
    }

    // OCR sonucu: önce kararlılık/tekrar kontrolü, sonra çeviri
    private void handleText(String raw) {
        String t = raw == null ? "" : raw.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (!Engine.looksLikeText(t)) {
            emptyCount++;
            candKey = null;
            candCount = 0;
            Status.ocr = "(yazı yok)";
            if (emptyCount >= 3 && lastShownKey != null) {
                lastShownKey = null;
                Engine.clear(ip);
            }
            busy.set(false);
            return;
        }
        emptyCount = 0;
        Status.ocr = t;
        String key = Engine.normKey(t);

        // Ekranda zaten gösterilen altyazıya çok benziyorsa (OCR titremesi) yok say
        if (lastShownKey != null && Engine.similarity(key, lastShownKey) >= 0.8) {
            candKey = null;
            candCount = 0;
            busy.set(false);
            return;
        }
        // Yeni metin art arda aynı okunmadıkça çevirme
        if (candKey != null && Engine.similarity(key, candKey) >= 0.85) {
            candCount++;
            if (t.length() >= candText.length()) {
                candText = t;
            }
        } else {
            candKey = key;
            candText = t;
            candCount = 1;
        }
        if (candCount < STABLE) {
            busy.set(false);
            return;
        }
        final String text = candText;
        lastShownKey = candKey;
        candKey = null;
        candCount = 0;

        if (!Engine.modelReady) {
            Status.tr = "Çeviri modeli henüz hazır değil";
            lastShownKey = null;
            busy.set(false);
            return;
        }
        translateText(text);
    }

    private static String titleCase(String name) {
        boolean allUpper = name.length() > 1 && name.equals(name.toUpperCase());
        if (!allUpper) {
            return name;
        }
        StringBuilder sb = new StringBuilder();
        boolean start = true;
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            sb.append(start ? Character.toUpperCase(c) : Character.toLowerCase(c));
            start = (c == ' ' || c == '-');
        }
        return sb.toString();
    }

    // "Ad: konuşma Ad2: konuşma" -> parçalar {ad, konuşma, büyükHarfMi}
    private List<String[]> parseSegments(String t) {
        List<String[]> segs = new ArrayList<>();
        Matcher m = SPEAKER.matcher(t);
        int last = 0;
        String cur = "";
        while (m.find()) {
            String name = m.group(1);
            if (NOT_SPEAKER.contains(name.toLowerCase())) {
                continue;
            }
            String before = t.substring(last, m.start()).trim();
            if (!before.isEmpty()) {
                segs.add(new String[]{cur, before});
            }
            cur = titleCase(name);
            last = m.end();
        }
        String rest = t.substring(last).trim();
        if (!rest.isEmpty()) {
            segs.add(new String[]{cur, rest});
        }
        if (segs.isEmpty()) {
            segs.add(new String[]{"", t});
        }
        return segs;
    }

    private void translateText(String text) {
        List<String[]> segs = parseSegments(text);
        translateAll(segs, 0, new ArrayList<String>());
    }

    private void translateAll(final List<String[]> segs, final int i, final List<String> out) {
        if (i == segs.size()) {
            sendResult(segs, out);
            return;
        }
        String body = segs.get(i)[1];
        boolean upper = Engine.mostlyUpper(body);
        if (upper) {
            body = Engine.sentenceCase(body);
        }
        Engine.translate(body, !upper, glossary, (res, err) -> {
            if (res == null) {
                Status.tr = "Çeviri hatası: " + err;
                lastShownKey = null;
                busy.set(false);
                return;
            }
            out.add(res);
            translateAll(segs, i + 1, out);
        });
    }

    private void sendResult(List<String[]> segs, List<String> out) {
        boolean named = false;
        for (String[] s : segs) {
            if (!s[0].isEmpty()) {
                named = true;
            }
        }
        StringBuilder sb = new StringBuilder();
        StringBuilder show = new StringBuilder();
        for (int i = 0; i < segs.size(); i++) {
            String name = segs.get(i)[0];
            String tr = out.get(i);
            if (named) {
                if (i > 0) {
                    sb.append('\u001e');
                    show.append("  |  ");
                }
                sb.append(name).append('\u001f').append(tr);
                show.append(name.isEmpty() ? "" : name + ": ").append(tr);
            } else {
                if (i > 0) {
                    sb.append(' ');
                    show.append(' ');
                }
                sb.append(tr);
                show.append(tr);
            }
        }
        Status.tr = show.toString();
        Engine.send(ip, sb.toString());
        busy.set(false);
    }

    // ---------- Bildirim ----------
    private void startAsForeground() {
        String channelId = "capture";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, "Ekran çevirisi",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        int pf = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent sel = PendingIntent.getService(this, 1,
                new Intent(this, CaptureService.class).setAction("SELECT"), pf);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, CaptureService.class).setAction("STOP"), pf);

        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        nb.setContentTitle("Çeviri Telefon");
        nb.setContentText("Ekran okunuyor");
        nb.setSmallIcon(android.R.drawable.ic_menu_camera);
        nb.addAction(android.R.drawable.ic_menu_crop, "Alanı seç", sel);
        nb.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Durdur", stop);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(5, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(5, n);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        instance = null;
        closeSelect();
        try {
            if (vd != null) {
                vd.release();
            }
            if (reader != null) {
                reader.close();
            }
            if (projection != null) {
                projection.stop();
            }
            if (ht != null) {
                ht.quitSafely();
            }
            if (recognizer != null) {
                recognizer.close();
            }
        } catch (Exception ignored) {
        }
        Status.cap = "Yakalama: durdu";
        stopForeground(true);
        super.onDestroy();
    }
}
