package com.kemal.ceviritelefon;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler bg;
    private TextRecognizer recognizer;
    private volatile boolean running = false;
    private final AtomicBoolean busy = new AtomicBoolean(false);

    private String ip = "";
    private int topPct = 70;
    private int bottomPct = 95;
    private String lastText = "";
    private int emptyCount = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running || intent == null) {
            return START_NOT_STICKY;
        }
        ip = intent.getStringExtra("ip");
        topPct = intent.getIntExtra("top", 70);
        bottomPct = intent.getIntExtra("bottom", 95);
        startAsForeground();
        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);

            ht = new HandlerThread("cap");
            ht.start();
            bg = new Handler(ht.getLooper());

            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                }
            }, bg);

            DisplayMetrics dm = new DisplayMetrics();
            ((WindowManager) getSystemService(WINDOW_SERVICE))
                    .getDefaultDisplay().getRealMetrics(dm);
            int scale = Math.max(dm.widthPixels, dm.heightPixels) > 2560 ? 2 : 1;
            int w = dm.widthPixels / scale;
            int h = dm.heightPixels / scale;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("cap", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, bg);

            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            if (!Engine.modelReady) {
                Engine.downloadModel();
            }
            running = true;
            Status.cap = "Yakalama: çalışıyor (" + w + "x" + h + ")";
            bg.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!running) {
                        return;
                    }
                    tick();
                    bg.postDelayed(this, 700);
                }
            }, 1000);
        } catch (Exception e) {
            Status.cap = "Yakalama başlatılamadı: " + e;
        }
        return START_NOT_STICKY;
    }

    private void tick() {
        if (busy.get()) {
            return;
        }
        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) {
                return;
            }
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int ps = p.getPixelStride();
            int rs = p.getRowStride();
            int w = img.getWidth();
            int h = img.getHeight();

            Bitmap full = Bitmap.createBitmap(rs / ps, h, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            int y0 = h * topPct / 100;
            int y1 = h * bottomPct / 100;
            if (y1 - y0 < 20) {
                y0 = h * 70 / 100;
                y1 = h * 95 / 100;
            }
            Bitmap crop = Bitmap.createBitmap(full, 0, y0, w, y1 - y0);
            full.recycle();

            busy.set(true);
            recognizer.process(InputImage.fromBitmap(crop, 0))
                    .addOnSuccessListener(res -> handleText(res.getText()))
                    .addOnFailureListener(e -> {
                        Status.ocr = "OCR hatası: " + e.getMessage();
                        busy.set(false);
                    });
        } catch (Exception e) {
            Status.cap = "Yakalama hatası: " + e;
            busy.set(false);
        } finally {
            if (img != null) {
                img.close();
            }
        }
    }

    private void handleText(String raw) {
        String t = raw == null ? "" : raw.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (t.length() < 4) {
            emptyCount++;
            Status.ocr = "(yazı yok)";
            if (emptyCount == 3 && !lastText.isEmpty()) {
                lastText = "";
                Engine.clear(ip);
            }
            busy.set(false);
            return;
        }
        emptyCount = 0;
        if (t.equals(lastText)) {
            busy.set(false);
            return;
        }
        lastText = t;
        Status.ocr = t;
        if (!Engine.modelReady) {
            Status.tr = "Çeviri modeli henüz hazır değil";
            busy.set(false);
            return;
        }
        String src = t.length() > 240 ? t.substring(0, 240) : t;
        Engine.translator.translate(src)
                .addOnSuccessListener(tr -> {
                    Status.tr = tr;
                    Engine.send(ip, tr);
                    busy.set(false);
                })
                .addOnFailureListener(e -> {
                    Status.tr = "Çeviri hatası: " + e.getMessage();
                    busy.set(false);
                });
    }

    private void startAsForeground() {
        String channelId = "capture";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, "Ekran çevirisi",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        nb.setContentTitle("Çeviri Telefon");
        nb.setContentText("Ekran okunuyor");
        nb.setSmallIcon(android.R.drawable.ic_menu_camera);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(5, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(5, n);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (vd != null) {
                vd.release();
            }
            if (reader != null) {
                reader.close();
            }
            if (projection != null) {
                projection.stop();
            }
            if (ht != null) {
                ht.quitSafely();
            }
            if (recognizer != null) {
                recognizer.close();
            }
        } catch (Exception ignored) {
        }
        Status.cap = "Yakalama: durdu";
        stopForeground(true);
        super.onDestroy();
    }
}
