package com.kemal.ceviritest;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.HashSet;

public class CaptureService extends Service {

    private WindowManager wm;
    private TextView tv;
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler bg;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;
    private String last = "";
    private int frames = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running || intent == null) {
            return START_NOT_STICKY;
        }
        startAsForeground();
        showOverlay();
        running = true;
        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);

            ht = new HandlerThread("cap");
            ht.start();
            bg = new Handler(ht.getLooper());

            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                }
            }, bg);

            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int scale = Math.max(1, dm.widthPixels / 1280);
            int w = dm.widthPixels / scale;
            int h = dm.heightPixels / scale;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("cap", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, bg);

            setText("EKRAN YAKALAMA TESTİ\n8 saniye içinde TV girişini Xbox'a çevir...");
            bg.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!running) {
                        return;
                    }
                    analyze();
                    bg.postDelayed(this, 3000);
                }
            }, 8000);
        } catch (Exception e) {
            setText("Yakalama başlatılamadı: " + e);
        }
        return START_NOT_STICKY;
    }

    private void analyze() {
        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) {
                setText(last + "\n(yeni kare yok)");
                return;
            }
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int ps = p.getPixelStride();
            int rs = p.getRowStride();
            int w = img.getWidth();
            int h = img.getHeight();
            long sum = 0;
            int cnt = 0;
            int black = 0;
            HashSet<Integer> colors = new HashSet<>();
            for (int y = 0; y < h / 2; y += 20) {
                for (int x = 0; x < w; x += 20) {
                    int o = y * rs + x * ps;
                    int r = buf.get(o) & 0xff;
                    int g = buf.get(o + 1) & 0xff;
                    int b = buf.get(o + 2) & 0xff;
                    int luma = (r * 3 + g * 6 + b) / 10;
                    sum += luma;
                    cnt++;
                    if (luma < 8) {
                        black++;
                    }
                    colors.add(((r >> 5) << 6) | ((g >> 5) << 3) | (b >> 5));
                }
            }
            frames++;
            last = "EKRAN YAKALAMA (kare " + frames + ")\nParlaklık ort.: " + (sum / cnt)
                    + "   Siyah oran: " + (black * 100 / cnt)
                    + "%   Farklı renk: " + colors.size();
            setText(last);
        } catch (Exception e) {
            setText("Yakalama hatası: " + e);
        } finally {
            if (img != null) {
                img.close();
            }
        }
    }

    private void startAsForeground() {
        String channelId = "capture";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, "Ekran testi",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        nb.setContentTitle("Ekran yakalama testi");
        nb.setContentText("Çalışıyor");
        nb.setSmallIcon(android.R.drawable.ic_menu_camera);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(3, n);
        }
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        tv = new TextView(this);
        tv.setText("Başlatılıyor...");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(26);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundColor(Color.argb(190, 0, 0, 0));
        tv.setPadding(30, 20, 30, 20);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;

        try {
            wm.addView(tv, lp);
        } catch (Exception e) {
            tv = null;
        }
    }

    private void setText(final String s) {
        ui.post(() -> {
            if (tv != null) {
                tv.setText(s);
            }
        });
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (vd != null) {
                vd.release();
            }
            if (reader != null) {
                reader.close();
            }
            if (projection != null) {
                projection.stop();
            }
            if (ht != null) {
                ht.quitSafely();
            }
        } catch (Exception ignored) {
        }
        if (tv != null) {
            try {
                wm.removeView(tv);
            } catch (Exception ignored) {
            }
            tv = null;
        }
        stopForeground(true);
        super.onDestroy();
    }
}
