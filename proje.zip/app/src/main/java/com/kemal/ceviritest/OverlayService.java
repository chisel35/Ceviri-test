package com.kemal.ceviritest;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

public class OverlayService extends Service {

    private WindowManager wm;
    private TextView tv;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (tv == null) {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            tv = new TextView(this);
            tv.setText("ALTYAZI TESTİ: Bu yazıyı Xbox ekranının üstünde görüyor musun?");
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(28);
            tv.setGravity(Gravity.CENTER);
            tv.setBackgroundColor(Color.argb(170, 0, 0, 0));
            tv.setPadding(30, 20, 30, 20);

            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM;

            try {
                wm.addView(tv, lp);
            } catch (Exception e) {
                tv = null;
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (tv != null) {
            try {
                wm.removeView(tv);
            } catch (Exception ignored) {
            }
            tv = null;
        }
        super.onDestroy();
    }
}
