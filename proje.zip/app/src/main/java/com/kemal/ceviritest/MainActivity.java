package com.kemal.ceviritest;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(60, 40, 60, 40);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#101418"));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Çeviri Test (Aşama 0)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        root.addView(title);

        Button b1 = addButton(root, "1) Overlay iznini aç");
        Button b2 = addButton(root, "2) Altyazı katmanını göster");
        Button b3 = addButton(root, "3) Altyazı katmanını gizle");
        Button b4 = addButton(root, "4) Mikrofon testi (5 sn)");

        out = new TextView(this);
        out.setTextColor(Color.parseColor("#C8D1DC"));
        out.setTextSize(20);
        out.setPadding(0, 30, 0, 0);
        out.setText(deviceInfo());
        root.addView(out);

        b1.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                log("Overlay izin ekranı bu TV'de açılamadı: " + e.getClass().getSimpleName());
            }
        });

        b2.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                log("Overlay izni YOK. (1. düğme izin ekranını açamadıysa bu TV'de overlay kapalı demektir.)");
                return;
            }
            startService(new Intent(this, OverlayService.class));
            log("Katman gösterildi. Şimdi TV girişini Xbox'a (HDMI) çevir; altta yazı görünüyor mu?");
        });

        b3.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            log("Katman gizlendi.");
        });

        b4.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                log("Mikrofon izni istendi. İzin verdiysen 4. düğmeye tekrar bas.");
                return;
            }
            runMicTest();
        });

        b1.requestFocus();
    }

    private Button addButton(LinearLayout parent, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(20);
        b.setFocusable(true);
        parent.addView(b);
        return b;
    }

    private String deviceInfo() {
        PackageManager pm = getPackageManager();
        return "Model: " + Build.MANUFACTURER + " " + Build.MODEL
                + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nTV modu (leanback): " + pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
                + "\nMikrofon donanımı: " + pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)
                + "\nOverlay izni: " + Settings.canDrawOverlays(this)
                + "\n\nTest sırası: 1 → 2 → TV girişini Xbox'a çevir → altta yazı var mı? → geri dön → 3 → 4";
    }

    private void log(final String msg) {
        runOnUiThread(() -> out.append("\n• " + msg));
    }

    private void runMicTest() {
        log("Mikrofon dinleniyor (5 sn). Xbox'ta ses çalarken yap.");
        new Thread(() -> {
            AudioRecord ar = null;
            try {
                int rate = 16000;
                int min = AudioRecord.getMinBufferSize(rate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) {
                    log("Mikrofon desteklenmiyor (arabellek: " + min + ")");
                    return;
                }
                ar = new AudioRecord(MediaRecorder.AudioSource.MIC, rate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2);
                if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                    log("Mikrofon başlatılamadı.");
                    return;
                }
                ar.startRecording();
                short[] buf = new short[1024];
                int peak = 0;
                long end = System.currentTimeMillis() + 5000;
                while (System.currentTimeMillis() < end) {
                    int n = ar.read(buf, 0, buf.length);
                    for (int i = 0; i < n; i++) {
                        peak = Math.max(peak, Math.abs((int) buf[i]));
                    }
                }
                log("Mikrofon en yüksek seviye: " + peak + " / 32767");
            } catch (Exception e) {
                log("Mikrofon hatası: " + e);
            } finally {
                if (ar != null) {
                    try {
                        ar.stop();
                    } catch (Exception ignored) {
                    }
                    ar.release();
                }
            }
        }).start();
    }
}
