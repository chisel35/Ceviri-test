package com.kemal.ceviritest;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(60, 40, 60, 40);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#101418"));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Çeviri Test (Aşama 0 - v3)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        root.addView(title);

        Button b1 = addButton(root, "1) Overlay iznini aç");
        Button b2 = addButton(root, "2) Altyazı katmanını göster");
        Button b3 = addButton(root, "3) Tüm katmanları gizle / durdur");
        Button b4 = addButton(root, "4) Mikrofon testi (5 sn, uygulama açıkken)");
        Button b5 = addButton(root, "5) CANLI ses çubuğu - mikrofon (MIC)");
        Button b6 = addButton(root, "6) CANLI ses çubuğu - ses tanıma kaynağı");
        Button b7 = addButton(root, "7) EKRAN YAKALAMA testi (Xbox görüntüsü okunabiliyor mu?)");

        out = new TextView(this);
        out.setTextColor(Color.parseColor("#C8D1DC"));
        out.setTextSize(20);
        out.setPadding(0, 30, 0, 0);
        out.setText(deviceInfo());
        root.addView(out);

        b1.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                log("Overlay izin ekranı bu TV'de açılamadı: " + e.getClass().getSimpleName());
            }
        });

        b2.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                log("Overlay izni YOK.");
                return;
            }
            startService(new Intent(this, OverlayService.class));
            log("Katman gösterildi. TV girişini Xbox'a çevir; altta yazı görünüyor mu?");
        });

        b3.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            stopService(new Intent(this, MeterService.class));
            stopService(new Intent(this, CaptureService.class));
            log("Katmanlar durduruldu.");
        });

        b4.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                log("Mikrofon izni istendi. İzin verdiysen düğmeye tekrar bas.");
                return;
            }
            runMicTest();
        });

        b5.setOnClickListener(v -> startMeter(MediaRecorder.AudioSource.MIC));
        b6.setOnClickListener(v -> startMeter(MediaRecorder.AudioSource.VOICE_RECOGNITION));

        b7.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                log("Overlay izni yok.");
                return;
            }
            try {
                MediaProjectionManager m =
                        (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), 100);
            } catch (Exception e) {
                log("Ekran yakalama bu TV'de desteklenmiyor: " + e.getClass().getSimpleName());
            }
        });

        b1.requestFocus();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            if (resultCode != RESULT_OK || data == null) {
                log("Ekran yakalama izni verilmedi.");
                return;
            }
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("code", resultCode);
            i.putExtra("data", data);
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(i);
                } else {
                    startService(i);
                }
                log("Yakalama başladı. 8 saniye içinde TV girişini Xbox'a çevir, oyun/menü ekranı açıkken 15-20 sn bekle ve alttaki sayılara bak.");
            } catch (Exception e) {
                log("Servis başlatılamadı: " + e);
            }
        }
    }

    private Button addButton(LinearLayout parent, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(20);
        b.setFocusable(true);
        parent.addView(b);
        return b;
    }

    private String deviceInfo() {
        PackageManager pm = getPackageManager();
        return "Model: " + Build.MANUFACTURER + " " + Build.MODEL
                + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nTV modu (leanback): " + pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
                + "\nMikrofon donanımı: " + pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)
                + "\nOverlay izni: " + Settings.canDrawOverlays(this)
                + "\n\nYeni test: 7'ye bas → izin ver → TV girişini Xbox'a çevir → alttaki sayılara bak → geri dön → 3'e bas.";
    }

    private void startMeter(int source) {
        if (!Settings.canDrawOverlays(this)) {
            log("Overlay izni yok.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            log("Mikrofon izni istendi. İzin verdiysen düğmeye tekrar bas.");
            return;
        }
        stopService(new Intent(this, MeterService.class));
        Intent i = new Intent(this, MeterService.class);
        i.putExtra("source", source);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            log("Canlı ses çubuğu açıldı. TV girişini Xbox'a çevir ve ses çalarken çubuğa bak.");
        } catch (Exception e) {
            log("Servis başlatılamadı: " + e);
        }
    }

    private void log(final String msg) {
        runOnUiThread(() -> out.append("\n• " + msg));
    }

    private void runMicTest() {
        log("Mikrofon dinleniyor (5 sn).");
        new Thread(() -> {
            AudioRecord ar = null;
            try {
                int rate = 16000;
                int min = AudioRecord.getMinBufferSize(rate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) {
                    log("Mikrofon desteklenmiyor (arabellek: " + min + ")");
                    return;
                }
                ar = new AudioRecord(MediaRecorder.AudioSource.MIC, rate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2);
                if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                    log("Mikrofon başlatılamadı.");
                    return;
                }
                ar.startRecording();
                short[] buf = new short[1024];
                int peak = 0;
                long end = System.currentTimeMillis() + 5000;
                while (System.currentTimeMillis() < end) {
                    int n = ar.read(buf, 0, buf.length);
                    for (int i = 0; i < n; i++) {
                        peak = Math.max(peak, Math.abs((int) buf[i]));
                    }
                }
                log("Mikrofon en yüksek seviye: " + peak + " / 32767");
            } catch (Exception e) {
                log("Mikrofon hatası: " + e);
            } finally {
                if (ar != null) {
                    try {
                        ar.stop();
                    } catch (Exception ignored) {
                    }
                    ar.release();
                }
            }
        }).start();
    }
}
