package com.kemal.ceviritest;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class MainActivity extends Activity {

    private TextView out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(60, 40, 60, 40);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#101418"));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Çeviri Test (v4 - altyazı alıcısı)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        root.addView(title);

        Button b1 = addButton(root, "1) Overlay iznini aç");
        Button b2 = addButton(root, "2) Altyazı sunucusunu BAŞLAT");
        Button b3 = addButton(root, "3) Sunucuyu DURDUR");

        out = new TextView(this);
        out.setTextColor(Color.parseColor("#C8D1DC"));
        out.setTextSize(20);
        out.setPadding(0, 30, 0, 0);
        out.setText(info());
        root.addView(out);

        b1.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                log("Overlay izin ekranı açılamadı: " + e.getClass().getSimpleName());
            }
        });

        b2.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                log("Overlay izni yok. Önce 1'e bas.");
                return;
            }
            Intent i = new Intent(this, SubtitleService.class);
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(i);
                } else {
                    startService(i);
                }
                log("Sunucu başladı. Telefonun tarayıcısına şu adresi yaz:");
                log("http://" + localIp() + ":8765/s?t=Merhaba%20dünya");
                log("TV'de altyazı çıkmalı. Sonra TV girişini Xbox'a çevirip tekrar dene.");
            } catch (Exception e) {
                log("Sunucu başlatılamadı: " + e);
            }
        });

        b3.setOnClickListener(v -> {
            stopService(new Intent(this, SubtitleService.class));
            log("Sunucu durduruldu.");
        });

        b1.requestFocus();
    }

    private Button addButton(LinearLayout parent, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(20);
        b.setFocusable(true);
        parent.addView(b);
        return b;
    }

    private String info() {
        return "Model: " + Build.MANUFACTURER + " " + Build.MODEL
                + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nTV IP adresi: " + localIp()
                + "\nOverlay izni: " + Settings.canDrawOverlays(this)
                + "\n\nTest: 2'ye bas → telefonu aynı Wi-Fi'a bağla → telefonun tarayıcısına"
                + " http://" + localIp() + ":8765/s?t=Merhaba adresini yaz.";
    }

    private String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return "bulunamadı";
    }

    private void log(final String msg) {
        runOnUiThread(() -> out.append("\n• " + msg));
    }
}
