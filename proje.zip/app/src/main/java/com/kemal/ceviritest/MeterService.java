package com.kemal.ceviritest;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

public class MeterService extends Service {

    private WindowManager wm;
    private TextView tv;
    private volatile boolean running = false;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) {
            return START_NOT_STICKY;
        }
        final int source = intent != null ? intent.getIntExtra("source", 1) : 1;
        startAsForeground();
        showOverlay();
        running = true;
        new Thread(() -> record(source)).start();
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        String channelId = "meter";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, "Ses testi",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        nb.setContentTitle("Ses seviyesi testi");
        nb.setContentText("Dinleniyor");
        nb.setSmallIcon(android.R.drawable.ic_btn_speak_now);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(2, n);
        }
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        tv = new TextView(this);
        tv.setText("Ses seviyesi başlatılıyor...");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(26);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundColor(Color.argb(190, 0, 0, 0));
        tv.setPadding(30, 20, 30, 20);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;

        try {
            wm.addView(tv, lp);
        } catch (Exception e) {
            tv = null;
        }
    }

    private void setText(final String s) {
        ui.post(() -> {
            if (tv != null) {
                tv.setText(s);
            }
        });
    }

    private void record(int source) {
        AudioRecord ar = null;
        try {
            int rate = 16000;
            int min = AudioRecord.getMinBufferSize(rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) {
                setText("Mikrofon desteklenmiyor (arabellek: " + min + ")");
                return;
            }
            ar = new AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, min * 2);
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                setText("Mikrofon başlatılamadı (kaynak " + source + ")");
                return;
            }
            ar.startRecording();
            short[] buf = new short[1600];
            int maxEver = 0;
            int windowPeak = 0;
            long lastUpdate = 0;
            while (running) {
                int n = ar.read(buf, 0, buf.length);
                if (n < 0) {
                    setText("Okuma hatası: " + n);
                    return;
                }
                for (int i = 0; i < n; i++) {
                    windowPeak = Math.max(windowPeak, Math.abs((int) buf[i]));
                }
                long now = System.currentTimeMillis();
                if (now - lastUpdate > 300) {
                    maxEver = Math.max(maxEver, windowPeak);
                    int bars = Math.min(30, windowPeak * 30 / 3000);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < bars; i++) {
                        sb.append('█');
                    }
                    setText("SES SEVİYESİ (kaynak " + source + ")\n" + sb
                            + "\nŞimdi: " + windowPeak + "   En yüksek: " + maxEver + " / 32767");
                    windowPeak = 0;
                    lastUpdate = now;
                }
            }
        } catch (Exception e) {
            setText("Mikrofon hatası: " + e);
        } finally {
            if (ar != null) {
                try {
                    ar.stop();
                } catch (Exception ignored) {
                }
                ar.release();
            }
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (tv != null) {
            try {
                wm.removeView(tv);
            } catch (Exception ignored) {
            }
            tv = null;
        }
        stopForeground(true);
        super.onDestroy();
    }
}
