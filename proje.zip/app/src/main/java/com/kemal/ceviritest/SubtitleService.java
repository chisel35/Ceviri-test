package com.kemal.ceviritest;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;

public class SubtitleService extends Service {

    private static final int PORT = 8765;

    private WindowManager wm;
    private TextView tv;
    private ServerSocket server;
    private volatile boolean running = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable hide = () -> {
        if (tv != null) {
            tv.setVisibility(View.GONE);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) {
            return START_NOT_STICKY;
        }
        startAsForeground();
        showOverlay();
        running = true;
        show("Altyazı sunucusu hazır (port " + PORT + ")", 5000);
        new Thread(this::serverLoop).start();
        return START_NOT_STICKY;
    }

    private void serverLoop() {
        try {
            server = new ServerSocket(PORT);
            while (running) {
                Socket s = server.accept();
                handle(s);
            }
        } catch (Exception e) {
            if (running) {
                show("Sunucu hatası: " + e, 8000);
            }
        }
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(2000);
            BufferedReader r = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line = r.readLine();
            if (line != null) {
                String[] parts = line.split(" ");
                if (parts.length >= 2) {
                    String path = parts[1];
                    if (path.startsWith("/s?t=")) {
                        String raw = path.substring(5);
                        int amp = raw.indexOf('&');
                        if (amp >= 0) {
                            raw = raw.substring(0, amp);
                        }
                        show(URLDecoder.decode(raw, "UTF-8"), 6000);
                    } else if (path.startsWith("/clear")) {
                        show("", 0);
                    }
                }
            }
            byte[] body = "ok".getBytes("UTF-8");
            OutputStream o = s.getOutputStream();
            o.write(("HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n"
                    + "Access-Control-Allow-Origin: *\r\nContent-Length: " + body.length
                    + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
            o.write(body);
            o.flush();
        } catch (Exception ignored) {
        } finally {
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }

    private void show(final String text, final long ms) {
        ui.post(() -> {
            if (tv == null) {
                return;
            }
            ui.removeCallbacks(hide);
            if (text.isEmpty()) {
                tv.setVisibility(View.GONE);
                return;
            }
            tv.setText(text);
            tv.setVisibility(View.VISIBLE);
            ui.postDelayed(hide, ms);
        });
    }

    private void startAsForeground() {
        String channelId = "sub";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, "Altyazı sunucusu",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        nb.setContentTitle("Altyazı sunucusu");
        nb.setContentText("Çalışıyor");
        nb.setSmallIcon(android.R.drawable.ic_dialog_info);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(4, n, 1073741824);
        } else {
            startForeground(4, n);
        }
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        tv = new TextView(this);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(30);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundColor(Color.argb(170, 0, 0, 0));
        tv.setPadding(40, 20, 40, 20);
        tv.setVisibility(View.GONE);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;
        lp.y = 40;

        try {
            wm.addView(tv, lp);
        } catch (Exception e) {
            tv = null;
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (server != null) {
                server.close();
            }
        } catch (Exception ignored) {
        }
        ui.removeCallbacksAndMessages(null);
        if (tv != null) {
            try {
                wm.removeView(tv);
            } catch (Exception ignored) {
            }
            tv = null;
        }
        stopForeground(true);
        super.onDestroy();
    }
}
